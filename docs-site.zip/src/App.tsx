import React from 'react';
import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Sheet from '@mui/joy/Sheet';
import Stack from '@mui/joy/Stack';
import { styled } from '@mui/joy/styles';
import Card from '@mui/joy/Card';
import CardCover from '@mui/joy/CardCover';
import CardContent from '@mui/joy/CardContent';
import Typography from '@mui/joy/Typography';

const Item = styled(Sheet)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'left',
  color: theme.vars.palette.text.primary,
}));

function App() {
  return (
    <>
    <div className="Nav">
      <Navbar />
      </div>
    <div className="Row">
      <h3>👋, Welcome to SyncTheme documentation!</h3>
      <p>Here you can find all the information you need to get started with SyncTheme.</p>
      <p className="p">Enter this commands in root diretory of your server to perform clean installation!</p>
      <div className="Stack">
      <Stack spacing={2} sx={{ width: '60%' }}>
        <p className="p">1. Download and extract all files to /var/www/pterodactyl</p>
        <hr />
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
            git clone https://github.com/Antoniovbn000/synctheme.git
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          apt install -y unzip
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          cd synctheme && unzip SYNC.zip && cp -r * /var/www/pterodactyl
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
        <p className="p">2. Install all depencies</p>
        <hr />
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          apt install -y nodejs
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
        <p className="p">3. Install packages required for theme to work!</p>
        <hr />
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          npm i -g yarn
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          cd /var/www/pterodactyl && yarn install
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          yarn add @mui/material @emotion/react @emotion/styled
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          yarn add @mui/material @mui/styled-engine-sc styled-components
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          yarn add @mui/icons-material
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <Stack spacing={2} sx={{ width: '60%' }}>
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          yarn add @mui/joy @emotion/react @emotion/styled
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>  

      <Stack spacing={2} sx={{ width: '60%' }}>
        <p className="p">4. Build the panel</p>
        <hr />
      <Item>
        
      <Card sx={{ minWidth: 80 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="13px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
          yarn && yarn build:production
          </Typography>
        </div>
      </CardCover>
    </Card>


      </Item>
      </Stack>

      <p className="p">💥Once your theme is installed, refresh the page💥</p>
      <p className="p">💥If you need help or have errors/bugs dm AntonioVbn#7699 on discord!💥</p>

      </div>
      </div>
    </>
  );
}

export default App;
