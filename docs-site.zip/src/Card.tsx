import * as React from 'react';
import Card from '@mui/joy/Card';
import CardCover from '@mui/joy/CardCover';
import CardContent from '@mui/joy/CardContent';
import Typography from '@mui/joy/Typography';

export default function CardCovers() {
  return (
    <Card sx={{ minWidth: 50 }}>
      <CardCover sx={{ bgcolor: 'rgba(0,0,0,0.4)' }}>
        <div>
          <Typography
            fontSize="15px"
            fontWeight="lg"
            textColor="#fff"
            ml={2}
            flexGrow={1}
          >
            git clone https://github.com/Antoniovbn000/synctheme.git
          </Typography>
        </div>
      </CardCover>
    </Card>
  );
}
